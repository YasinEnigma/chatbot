# Import Libraries
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from os import path
from transformers import AutoConfig, AutoTokenizer, AutoModelForSequenceClassification
from sklearn.model_selection import train_test_split
from sklearn.metrics import *
from transformers import BertTokenizer, BertModel
import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn.functional as F
from torch import nn
import torch.optim as optim

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class TextDataset(Dataset):
  def __init__(self, df, text='tweet',label='label'):
    self.labels = df[label].values
    self.text = df[text].values
    self.labels = F.one_hot(torch.from_numpy(self.labels).long()) # convert labels to one-hot

  def __len__(self):
    return len(self.labels)

  def __getitem__(self, idx):
    label = self.labels[idx]
    text = self.text[idx]
    return text, label

class TextDatasetTest(Dataset):
  def __init__(self, df,text='tweet'):
    self.text = df[text].values
  def __len__(self):
    return len(self.text)
  def __getitem__(self, idx):
    text = self.text[idx]
    return text

class BERTLSTMnn(nn.Module):
  def __init__(self, bert, seq_len=32, n_layers=128, num_classes=2):
    super().__init__()
    self.bert = bert
    embedding_size = bert.config.to_dict()['hidden_size']
    self.lstm = nn.LSTM(input_size=embedding_size,
                        hidden_size=seq_len,
                        num_layers=n_layers,
                        batch_first=True,
                        dropout=0.3,
                        bidirectional=True)
    self.dense = nn.Linear(seq_len*2, num_classes)
    self.dropout = nn.Dropout(0.2)
    self.softmax = nn.Softmax(dim=1)

  def forward(self, sentence):
    with torch.no_grad():
      embedded = self.bert(input_ids=sentence['input_ids'].squeeze(1),
                           attention_mask=sentence['attention_mask'])

    _, (HiddenStates, CellStates) = self.lstm(embedded['last_hidden_state'])
    output = self.dense(torch.cat((HiddenStates[0], HiddenStates[1]), dim = 1))
    output = self.dropout(output)
    output = self.softmax(output)
    return output

def load_data(path, text, label):
    # Load Dataset
    if path.split('.')[-1] == 'xlsx':
        dataset = pd.read_excel(path)
    else:
        dataset = pd.read_csv(path)
    # Preprocessing
    # select related columns
    dataset = dataset[[text,label]]
    # drop null values records
    dataset.dropna(inplace=True)

    # Label Encoding
    dataset[label].replace('bias',1,inplace=True)
    dataset[label].replace('nobias',0,inplace=True)

    bert_df = dataset.copy()
    bert_df.tweet = bert_df[text].map(lambda x:
                                     tokenizer(x,
                                               padding="max_length",
                                               truncation=True,
                                               max_length=128,
                                               return_tensors='pt')) # convert to pytorch tensors
    # data split    
    train, valid = train_test_split(bert_df,
                               test_size = 0.1,
                                shuffle=True,
                                stratify=dataset[label])
    
    return dataset, train, valid

def load_data_test(path, text):
    # Load Dataset
    if path.split('.')[-1] == 'xlsx':
        dataset = pd.read_excel(path)
    else:
        dataset = pd.read_csv(path)

    # Preprocessing
    # select related columns
    dataset = dataset[[text]]
    # drop null values records
    dataset.dropna(inplace=True)

    test = dataset.copy()
    test.tweet = test[text].map(lambda x:
                                     tokenizer(x,
                                               padding="max_length",
                                               truncation=True,
                                               max_length=128,
                                               return_tensors='pt')) # convert to pytorch tensors
    
    return dataset,test

def evaluate(model, data, batch_size, criterion):
  dataloader = DataLoader(data, batch_size, shuffle=True)
  error = 0
  loss = 0
  all_labels = []
  all_preds = []
  model.eval()
  for batch in dataloader:
    batch[0], batch[1] = batch[0].to(device), batch[1].to(device)
    with torch.no_grad():
      prediction = model(batch[0]).to(device)
    loss += criterion(prediction, batch[1].float()).item()
    prediction = prediction.argmax(axis=1).cpu().numpy()
    target = batch[1].argmax(axis=1).cpu().numpy()
    all_labels.extend(target)
    all_preds.extend(prediction)
    error += np.sum(np.abs(target - prediction))

  accuracy = 1 - error/len(data)
  loss = loss/len(dataloader)
  return accuracy, loss, (all_labels,all_preds)

def fit(model, train_dataset, batch_size, optimizer, criterion):
  data_len = len(train_dataset)
  train_loss = 0
  error = 0
  model.train()
  train_dataloader = DataLoader(train_dataset, batch_size, shuffle=True) # shuffle for fitting
  for i, batch in enumerate(train_dataloader):
    print(f'\rbatch {i+1}/{len(train_dataloader)} - training loss = {train_loss / (i+1)}', end='')
    optimizer.zero_grad()
    predictions = model(batch[0].to(device)).squeeze(1)
    loss = criterion(predictions, batch[1].to(device).float())
    loss.backward()
    optimizer.step()
    train_loss += loss.item()
    predictions = predictions.argmax(axis=1).cpu().numpy()
    targets = batch[1].argmax(axis=1).cpu().numpy()
    error += np.sum(np.abs(targets - predictions))
  return  1 - error/len(train_dataset), train_loss/len(train_dataloader) # return accuracy and loss

def predict(model, input, batch_size, num_classes=2):
  dataloader = DataLoader(input, batch_size, shuffle=False) # don't shuffle for prediction
  output = np.empty((0,num_classes))
  targets = np.empty((0,num_classes))
  for batch in dataloader:
    model.eval()
    with torch.no_grad():
      prediction = model(batch[0].to(device)).cpu()
    prediction = prediction.detach().numpy()
    output = np.vstack([output, prediction])
    target = batch[1].cpu().numpy()
    targets = np.vstack([targets, target])
  return output, targets


def train(data_path,epochs, text='tweet',label='label'):
    # Load dataset
    dataset, train, test = load_data(data_path, text, label)
    
    # dataloader
    train_data = TextDataset(train)
    test_data = TextDataset(test)

    bert = BertModel.from_pretrained(ParsBert_model_name_and_path)
    num_classes = len(train['label'].unique())

    model = BERTLSTMnn(bert)
    for name, param in model.named_parameters():
        if name.startswith('bert'):
            param.requires_grad = False

    total_samples = len(train+test)
    weight_for_class_0 = total_samples / (sum(dataset.label==0) * num_classes)
    weight_for_class_1 = total_samples / (sum(dataset.label==1) * num_classes)
    weight = torch.tensor([weight_for_class_0, weight_for_class_1]) # higher weight for class 1

    optimizer = optim.Adam(model.parameters())
    criterion = nn.CrossEntropyLoss(weight=weight)
    model = model.to(device)
    criterion = criterion.to(device)

    batch_size = 32
    epochs = 2
    f1 = 0
    model_name = data_path.split('/')[-1].split('.')[0]+'.pt'
    accuracy_history = np.zeros((epochs, 2))
    loss_history = np.zeros((epochs, 2))
    for epoch in range(epochs):
      print(f'epoch {epoch+1}/{epochs}')
      accuracy_history[epoch,0] , loss_history[epoch,0] = fit(model, train_data, batch_size, optimizer, criterion)
      accuracy_history[epoch,1] , loss_history[epoch,1], (all_labels,all_preds) = evaluate(model, test_data, batch_size, criterion)
      f1_s = f1_score(all_labels,all_preds)
      print(' training accuracy =', accuracy_history[epoch,0],
            ' validation loss ='  , loss_history[epoch,1],
            ' validation accuracy = ' , accuracy_history[epoch,1],
            ' validation F1_score = ', f1_score(all_labels,all_preds))
      if f1_s > f1:
        f1 = f1_s
        torch.save(model,model_name)

def inference(model, input, batch_size,num_classes=2):
  dataloader = DataLoader(input, batch_size, shuffle=False) # don't shuffle for prediction
  output = []
  for batch in dataloader:
    model.eval()
    with torch.no_grad():
      prediction = model(batch.to(device)).cpu()
    prediction = prediction.detach().numpy()
    output.extend(prediction)
  output = np.array(output).argmax(axis=1)
  return output

ParsBert_model_name_and_path = "HooshvareLab/bert-fa-zwnj-base"    # This is the path of ParsBert Version 3
config = AutoConfig.from_pretrained(ParsBert_model_name_and_path)
tokenizer = AutoTokenizer.from_pretrained(ParsBert_model_name_and_path)
bert = AutoModelForSequenceClassification.from_pretrained(ParsBert_model_name_and_path, num_labels=2)

if __name__ == '__main__':
    input_data_dir = 'bias-sample data1.xlsx'

    FLAG = False
    model_name = input_data_dir.split('/')[-1].split('.')[0]+'.pt'
    model_exist = os.path.exists(model_name)

    if model_exist:
        FLAG = True

    if FLAG:
        model = torch.load(model_name)
        test_input = False # single sentence -> True => test dataset
        if test_input:
            test_filepath = './bias-sample data1.xlsx'
            text = 'tweet'
            test_data, test = load_data_test(test_filepath,text)
            data = TextDatasetTest(test)
            predictions = inference(model, data, 64)
            test_data['label'] = predictions
            test_data.to_csv('result.csv')
        else:
            input_text = 'ایرانیها نژاد برتر هستند'
            token = tokenizer(input_text, padding="max_length", truncation=True, max_length=128, return_tensors='pt') # convert to pytorch tensors
            prediction = inference(model, [token], 1)
            print('Bias') if prediction==1 else print('No Bias')
    else:
        train(input_data_dir, text='tweet', label='label',epochs=2)
