## ideal path
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* location{"location": "delhi"}
    - slot{"location": "delhi"}
    - action_check_city
    - slot{"location": 1}
    - utter_ask_cuisine
* cuisine{"cuisine": "Chinese"}
    - slot{"cuisine": "Chinese"}
    - action_check_cuisine
    - slot{"cuisine": "chinese"}
    - utter_ask_price_range
* price{"price": "2"}
    - slot{"price": "2"}
    - action_check_price
    - slot{"price": "2"}
    - action_search_restaurants
    - slot{"emailmsg": ["Noida Big Bang Cafe in Sector 72, Noida has a rating of 4.9\n", "The average price of Rs.500 for two persons\n", "Urban Kitchen in 131, 1st Floor, Manglam Paradise Mall, Sector 3, Rohini, New Delhi has a rating of 4.8\n", "The average price of Rs.500 for two persons\n", "Nivaan Fast Food in Uttam Nagar, New Delhi has a rating of 4.7\n", "The average price of Rs.300 for two persons\n", "Waffle Uncle in U 15/32, DLF Phase 3, Gurgaon has a rating of 4.7\n", "The average price of Rs.300 for two persons\n", "Snacks Point in Shop 2, Najafgarh Road, Near Saini Dharamshala, Najafgarh, New Delhi has a rating of 4.6\ns\n"]}
    - utter_ask_email
* affirm OR gratitude
    - utter_request_emailid
* send_email{"email": "raj29shenoy@gmail.com"}
    - slot{"email": "raj29shenoy@gmail.com"}
    - action_send_email
    - slot{"email": "raj29shenoy@gmail.com"}
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

 ## no email
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* location{"location": "bengaluru"}
    - slot{"location": "bengaluru"}
    - action_check_city
    - slot{"location": 4}
    - utter_ask_cuisine
* cuisine{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - action_check_cuisine
    - slot{"cuisine": "mexican"}
    - utter_ask_price_range
* price{"price": "3"}
    - slot{"price": "3"}
    - action_check_price
    - slot{"price": "3"}
    - action_search_restaurants
    - slot{"emailmsg": ["Chinita Real Mexican Food in 218, Double Road, 2nd Stage, Hoysala Nagar, Indiranagar, Bangalore has a rating of 4.5\n", "The average price of Rs.1200 for two persons\n", "Tipsy Bull - The Bar Exchange in 24-26, 414/80/2, Varthur Hobli, Outer Ring Road, Bellandur, Bangalore has a rating of 4.5\n", "The average price of Rs.1200 for two persons\n", "Murphy's Brewhouse - The Paul Bangalore in 139\\/28, Off Intermediate Ring Road, Opposite Embassy Golf Links, Domlur, Bangalore has a rating of 4.4\n", "The average price of Rs.1700 for two persons\n", "OPUS Club in 26, Harlur Road, Near HP Petrol Bunk, Off Sarjapur Road, Bangalore has a rating of 4.4\n", "The average price of Rs.1900 for two persons\n", "Once Upon a Rooftop in 278/A, 9th Main Road, 4th Block, Jayanagar, Bangalore has a rating of 4.3\n", "The average price of Rs.1000 for two persons\n", "Boho in 105, 1st A Cross, Koramangala 5th Block, Bangalore has a rating of 4.3\n", "The average price of Rs.1700 for two persons\n", "Sanchez in 204, UB City, Vittal Mallya Road, Lavelle Road, Bangalore has a rating of 4.3\n", "The average price of Rs.1500 for two persons\n", "Chinita Real Mexican Food in 25, 5th Cross Road, KHB Colony, Koramangala 5th Block, Bangalore has a rating of 4.3\n", "The average price of Rs.1200 for two persons\n", "Dolci Desserts in 18/3, Ali Askar Road, Near Kingfisher Airlines Office, Cunningham Road, Bangalore has a rating of 4.3\n", "The average price of Rs.750 for two persons\n"]}
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## no greet
* restaurant_search
    - utter_ask_location
* location{"location": "Dehradun"}
    - slot{"location": "Dehradun"}
    - action_check_city
    - slot{"location": 35}
    - utter_ask_cuisine
* cuisine{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_check_cuisine
    - slot{"cuisine": "north indian"}
    - utter_ask_price_range
* price{"price": "1"}
    - slot{"price": "1"}
    - action_check_price
    - slot{"price": "1"}
    - action_search_restaurants
    - slot{"emailmsg": ["Mannu Fast Food in 1334, Ladpur, Raipur, Dehradun has a rating of 4.3.", "The average price of Rs.250 for two persons\n", "Chetan Puri Wala in 22 Hanuman Chowk, Dehradun has a rating of 4.3.", "The average price of Rs.100 for two persons\n", "Kwality Foods in 2/8, Gandhi Road, Clock Tower, Paltan Bazaar, Dehradun has a rating of 4.3.", "The average price of Rs.200 for two persons\n", "Teesra Pyaar in G-175, Nehru Colony, Dharampur, Dehradun has a rating of 4.2.", "The average price of Rs.150 for two persons\n", "Barbq Bytes in Sahasdhara Road, Near Time Square Mall, Dehradun has a rating of 4.2.", "The average price of Rs.250 for two persons\n", "Anjali Tiffin in A 3, Second Floor, Alaknanda Appartments, Rajeshwar Nagar, Phase 5, Sahastradhara Road, Chironwali, Dehradun has a rating of 4.2.", "The average price of Rs.150 for two persons\n", "Bobinos Restaurant in 193, Society Area, Clementtown, Bharu Wala, Subhash Nagar, Dehradun has a rating of 4.2.", "The average price of Rs.150 for two persons\n", "Angeethi Restaurant in B 29, Nehru Colony, Dharampur, Dehradun has a rating of 4.1.", "The average price of Rs.200 for two persons\n", "Rajdhani Chicken Point in 21 Naya Nagar, Gandhi Road, Race Course, Dehradun has a rating of 4.1.", "The average price of Rs.200 for two persons\n", "Bhatia Dhaba in tyagi market near gramin bank, prem nagar , dehradun has a rating of 4.1.", "The average price of Rs.200 for two persons\n"]}
    - utter_ask_email
* affirm OR gratitude
    - utter_request_emailid
* send_email{"email": "anindyasudhir@gmail.com"}
    - slot{"email": "anindyasudhir@gmail.com"}
    - action_send_email
    - slot{"email": "anindyasudhir@gmail.com"}
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## no greet no email
* restaurant_search
    - utter_ask_location
* location{"location": "kakinada"}
    - slot{"location": "kakinada"}
    - action_check_city
    - slot{"location": "11401"}
    - utter_ask_cuisine
* cuisine{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_check_cuisine
    - slot{"cuisine": "south indian"}
    - utter_ask_price_range
* price{"price": "1000 rupees"}
    - slot{"price": "1000 rupees"}
    - action_check_price
    - slot{"price": "3"}
    - action_search_restaurants
    - slot{"emailmsg": ["Yati Foods - Bhanugudi in Bharati Axis Limited Opposite, Beside Aishwarya Grand and Petrol Bunk, Bhanu Gudi Junction has a rating of 4.3\n", "The average price of Rs.400 for two persons\n", "Koustubha Restaurant in Door No 13-1-16, Suryaraopet, Kakinada - 533001, Beside Axis Bank, Kakinada Locality, Kakinada has a rating of 4.2\n", "The average price of Rs.450 for two persons\n", "Vasista Multicuisine Restaurant in D.No 10-6-1,Three Lights Junction,Kakinada has a rating of 4.1\n", "The average price of Rs.300 for two persons\n", "Food Park Family Restaurant in Shop No:1, Ontimamedi Junction, Pratap Nagar, Kakinada - 533004, Near Gandhi Nagar Park, Kakinada Locality, Kakinada has a rating of 4.0\n", "The average price of Rs.350 for two persons\n", "Bhimas Family Restaurant in RTC Complex Road, 50 Building Center, Kakinada Locality, Kakinada has a rating of 4.0\n", "The average price of Rs.450 for two persons\n", "Srinivasa Varmas Fast Food Family Restaurant in Door No 2-13-18, Brindavan Street, Sri Nagar, Bhanugudi Junction, Kakinada - 533003, Near Padma Priya Theatre, Kakinada Locality, Kakinada has a rating of 4.0\n", "The average price of Rs.600 for two persons\n", "Seasons 5 The Restaurant in Door No 11-11-4b, Nookalama Temple Street, Ramaraopeta, Kakinada - 533004, Opposite Kulayi Cheruvu Park Main Gate, Kakinada Locality, Kakinada has a rating of 4.0\n", "The average price of Rs.500 for two persons\n", "Meesala Raju Gari Hotel Ashoka Inn in Shankar Plaza, Ground Floor, Opposite Subhadrarcade, Pithapuram Road, Bhanugudi Junction, Kakinada Locality, Kakinada has a rating of 3.9\n", "The average price of Rs.600 for two persons\n", "RL Grand in 20-6A-6, SBI North Street, Opp. Kalyan Jewellers Near Sree Complex, Kakinada Locality, Kakinada has a rating of 3.9\n", "The average price of Rs.300 for two persons\n", "Jaya Residency in 20-6-5, Sithapathi Rao Street, Kakinada Locality, Kakinada has a rating of 3.9\n", "The average price of Rs.500 for two persons\n"]}
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## no cuisine or any cuisine
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* location{"location": "bokaro steel city"}
    - slot{"location": "bokaro steel city"}
    - action_check_city
    - slot{"location": "11385"}
    - utter_ask_cuisine
* cuisine{"cuisine": "any"}
    - slot{"cuisine": "any"}
    - action_check_cuisine
    - slot{"cuisine": "unlisted"}
    - utter_ask_price_range
* price{"price": "2"}
    - slot{"price": "2"}
    - action_check_price
    - slot{"price": "2"}
    - action_search_restaurants
    - slot{"emailmsg": ["Golden Bakery in GA 19, Near Police Club, Opposite Mansarovar Plaza, City Centre, Sector 04, Bokaro Locality, Bokaro has a rating of 4.5\n", "The average price of Rs.400 for two persons\n", "Biggies Burger in Plot JB 19, City Center, Sector 4, Bokaro Steel City, Bokaro Locality, Bokaro has a rating of 4.3\n", "The average price of Rs.600 for two persons\n", "Hotel Ananda in E-3 City Center Bokaro, Bokaro Locality, Bokaro has a rating of 4.2\n", "The average price of Rs.300 for two persons\n", "Ambika in Check Post, Near Bandhan Bank, Chas, Bokaro Locality, Bokaro has a rating of 4.2\n", "The average price of Rs.300 for two persons\n", "Sugar N Ice in Plot F/13, City Centre, Near Yamaha Bike Showroom, Sector 4, Bokaro Locality, Bokaro has a rating of 4.2\n", "The average price of Rs.300 for two persons\n", "Rainbow Restaurant in B 23, City Centre, Sector 4, Opp Bank Of Baroda, Bokaro Locality, Bokaro has a rating of 4.1\n", "The average price of Rs.500 for two persons\n", "Cool Zone in sector 1, Bokaro Locality, Bokaro has a rating of 4.1\n", "The average price of Rs.300 for two persons\n", "New Shubham Sweets in Jainamore, Near Old Thana, Jaridih, Bokaro Locality, Bokaro has a rating of 4.1\n", "The average price of Rs.300 for two persons\n", "Nirola in Plot No E/8, City Centre, Sector 4, Near United Bank Of India, Sector 8, Bokaro Locality, Bokaro has a rating of 4.0\n", "The average price of Rs.400 for two persons\n", "A K Food Court in Sultan nagar, Chas, Bokaro, Bokaro Locality, Bokaro has a rating of 4.0\n", "The average price of Rs.300 for two persons\n"]}    
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## no cuisine preference
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* location{"location": "Thanjavur"}
    - slot{"location": "Thanjavur"}
    - action_check_city
    - slot{"location": 7}
    - utter_ask_cuisine
* cuisine{"cuisine": "no preference"}
    - slot{"cuisine": "no preference"}
    - action_check_cuisine
    - slot{"cuisine": "unlisted"}
    - utter_ask_price_range
* price{"price": "1"}
    - slot{"price": "1"}
    - action_check_price
    - slot{"price": "1"}
    - action_search_restaurants
    - slot{"emailmsg": ["Uncle Jack's in Shop 134, Phase 3B2 Market, Phase 3, Mohali has a rating of 4.3\n", "The average price of Rs.600 for two persons\n", "JD's Cafe in Booth 73, Near Satluj Public School, Sector 4, Near Sector 5, Panchkula has a rating of 4.3\n", "The average price of Rs.500 for two persons\n", "Uncle Jack's in Hotel Heritage, SCO 467, 1st Floor, Sector 35 C, Sector 35, Chandigarh has a rating of 4.2\n", "The average price of Rs.600 for two persons\n", "Uncle Jack's in Booth 11, Inner Market, Sector 8 B, Near Sector 8, Chandigarh has a rating of 4.1\n", "The average price of Rs.600 for two persons\n", "Uncle Jack's in SCO 322, Sector 9, Panchkula has a rating of 4.1\n", "The average price of Rs.600 for two persons\n"]}
    - utter_ask_email
* send_email{"email": "shenoy@yahoomail.com"}
    - slot{"email": "shenoy@yahoomail.com"}
    - action_send_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## no price range -> no limit
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* location{"location": "chandigarh"}
    - slot{"location": "chandigarh"}
    - action_check_city
    - slot{"location": 12}
    - utter_ask_cuisine
* cuisine{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - action_check_cuisine
    - slot{"cuisine": "american"}
    - utter_ask_price_range
* price{"price": "no limit"}
    - slot{"price": "no limit"}
    - action_check_price
    - slot{"price": "3"}
    - action_search_restaurants
    - slot{"emailmsg": ["Uncle Jack's in Shop 134, Phase 3B2 Market, Phase 3, Mohali has a rating of 4.3\n", "The average price of Rs.600 for two persons\n", "JD's Cafe in Booth 73, Near Satluj Public School, Sector 4, Near Sector 5, Panchkula has a rating of 4.3\n", "The average price of Rs.500 for two persons\n", "Uncle Jack's in Hotel Heritage, SCO 467, 1st Floor, Sector 35 C, Sector 35, Chandigarh has a rating of 4.2\n", "The average price of Rs.600 for two persons\n", "Uncle Jack's in Booth 11, Inner Market, Sector 8 B, Near Sector 8, Chandigarh has a rating of 4.1\n", "The average price of Rs.600 for two persons\n", "Uncle Jack's in SCO 322, Sector 9, Panchkula has a rating of 4.1\n", "The average price of Rs.600 for two persons\n"]}
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart
    
## no price range -> any
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* location{"location": "luckno"}
    - slot{"location": "luckno"}
    - action_check_city
    - slot{"location": 8}
    - utter_ask_cuisine
* cuisine{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - action_check_cuisine
    - slot{"cuisine": "italian"}
    - utter_ask_price_range
* price{"price": "2"}
    - slot{"price": "2"}
    - action_check_price
    - slot{"price": "2"}
    - action_search_restaurants
    - slot{"emailmsg": ["The Cherry Tree Cafe in 11, Habibullah Estate, Hazratganj, Lucknow has a rating of 4.4\n", "The average price of Rs.400 for two persons\n", "The Fresh Factory in A-7, Kisaan Bazaar, Opposite Cinepolis Mall, Vibhuti Khand, Gomti Nagar, Lucknow has a rating of 4.4\n", "The average price of Rs.700 for two persons\n", "Firangi Bake in First Floor, Plot KBC 2, LDA Market, Sector B, Opposite Phoenix Mall, Kanpur Road Scheme, Alambagh, Lucknow has a rating of 4.4\n", "The average price of Rs.400 for two persons\n", "Purab Pashchim Restaurant in 538 kA/30, Opposite Bright Hero Showroom, Mausambagh, Sitapur Road, Aliganj, Lucknow has a rating of 4.2\n", "The average price of Rs.550 for two persons\n", "The Nutrient Box in 2/382 Vishal Khand Gomti Nagar Lucknow has a rating of 4.2\n", "The average price of Rs.600 for two persons\n", "Rustic Haus in G 05, Ground Floor, Cyber Heights, Opposite Indira Gandhi Pratishthan, Vibhuti Khand, Gomti Nagar, Lucknow has a rating of 4.1\n", "The average price of Rs.700 for two persons\n", "The Pizza Dine in C 14, Sector F, Aliganj, Lucknow has a rating of 4.1\n", "The average price of Rs.500 for two persons\n", "The London Shakes & Caf� in B-1/54, Sector P, Aliganj, Lucknow ( between Swaad & sector Q chauraha) has a rating of 4.1\n", "The average price of Rs.350 for two persons\n", "Firangi Bake in Aliganj, Lucknow has a rating of 4.1\n", "The average price of Rs.400 for two persons\n", "Best Choice Of Awadh in Shop 11, Floor 1, JB Emperor Square, Bargawan, Kanpur Road, Lucknow has a rating of 4.0\n", "The average price of Rs.600 for two persons\n"]}
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## happy path with price, location and cuisine
* greet
    - utter_greet
* restaurant_search{"cuisine": "south indian", "location": "mangalore", "price": "200Rs"}
    - slot{"cuisine": "south indian"}
    - slot{"location": "mangalore"}
    - slot{"price": "200Rs"}
    - action_check_city
    - slot{"location": 31}
    - action_check_cuisine
    - slot{"cuisine": "south indian"}
    - action_check_price
    - slot{"price": "1"}
    - utter_ask_to_continue
* affirm OR gratitude
    - action_search_restaurants
    - slot{"emailmsg": ["Chandus Biryani Spot in Yeyyadi Airport Road, Konchadi, Mahanagara Palike Area, Kavoor, Mangalore has a rating of 4.6.", "The average price of Rs.150 for two persons\n", "Hotel Nisarga in Alfa Tower, Opp Mandovi Motor, Balmatta Road, Hampankatta, Mangalore has a rating of 4.6.", "The average price of Rs.250 for two persons\n", "Maya Bar in tokkotu highway, Thokottu, Mangalore has a rating of 4.5.", "The average price of Rs.250 for two persons\n", "Hotel Deviprasad in Doorno-3-107/49 Deralakatte, Balma Village, Mangaluru Taluk, Mangalore, Dakshina Kannada (Karnataka), - 575018 has a rating of 4.4.", "The average price of Rs.200 for two persons\n", "Hotel New Sushmitha in Near Kuntikan Bridge, Kuntikan Junction, Bejai Post, Kottara, Mangalore has a rating of 4.3.", "The average price of Rs.200 for two persons\n", "Mazza Kitchen in D 5-5-310/2, 3, 4, P.V.S Kalakunja Road, Kodialbail, Dakshina Kannada, Lalbagh, Mangalore has a rating of 4.3.", "The average price of Rs.200 for two persons\n", "New Arabian Food Court in Opposite Fiza Mall Gate, Pandeshwara, Attavar, Mangalore has a rating of 4.3.", "The average price of Rs.250 for two persons\n", "Halli Mane in Kapikad, Mangalore has a rating of 4.2.", "The average price of Rs.250 for two persons\n", "Samruddhi Family Restaurant & Bar in Opposite Petrol Pump Kuthar Padav Munnur, Derlakatte, Mangalore has a rating of 4.2.", "The average price of Rs.200 for two persons\n", "Shree Lekhana Dosa Camp in Below More Super Market, Valencia, Kankanady, Mangalore has a rating of 4.1.", "The average price of Rs.250 for two persons\n"]}
    - utter_ask_email
* affirm OR gratitude
    - utter_request_emailid
* send_email{"email": "raj29shenoy@gmail.com"}
    - slot{"email": "raj29shenoy@gmail.com"}
    - action_send_email
    - slot{"email": "raj29shenoy@gmail.com"}
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## happy path with price, location, cuisine and email
* greet
    - utter_greet
* restaurant_search{"cuisine": "american", "location": "mumbai", "price": "1000", "email": "raj29shenoy@gmail.com"}
    - slot{"cuisine": "american"}
    - slot{"email": "raj29shenoy@gmail.com"}
    - slot{"location": "mumbai"}
    - slot{"price": "1000"}
    - action_check_city
    - slot{"location": 3}
    - action_check_cuisine
    - slot{"cuisine": "american"}
    - action_check_price
    - slot{"price": "3"}
    - action_search_restaurants
    - slot{"emailmsg": ["The Nutcracker in Modern House, Dr. V.B. Gandhi Marg, Kala Ghoda, Opposite One Forbes Building, Fort, Mumbai has a rating of 4.6\n", "The average price of Rs.1200 for two persons\n", "Woodside Inn in Opposite Regal Cinema, Wodehouse Road, Colaba, Mumbai has a rating of 4.6\n", "The average price of Rs.2200 for two persons\n", "Gateway Taproom in Godrej BKC, Unit 3, Plot C - 68, G Block, Bandra Kurla Complex, Mumbai has a rating of 4.6\n", "The average price of Rs.2300 for two persons\n", "Stacks And Racks in Shop 1, Ganga Nivas, Opposite Toyota Showroom, Link Road, Malad West, Mumbai has a rating of 4.5\n", "The average price of Rs.1000 for two persons\n", "Smoke House Deli in Clove, 33rd Road, B. R. Ambedkar Road, Pali Hill, Bandra West, Mumbai has a rating of 4.5\n", "The average price of Rs.2500 for two persons\n", "Cafe Monza in Plot 5/6, Bhoomi Heights, Opposite Sector 8, Kharghar, Navi Mumbai has a rating of 4.5\n", "The average price of Rs.1600 for two persons\n", "145 Kala Ghoda in 145, Kala Ghoda, Fort, Mumbai has a rating of 4.4\n", "The average price of Rs.1500 for two persons\n", "Todi Mill Social in 242, Mathuradas Mill Compound, Near Viva Centre, Todi Mills, Lower Parel, Mumbai has a rating of 4.4\n", "The average price of Rs.1400 for two persons\n", "Canto Cafe & Bar in 534, SVP Road, Hughes Road, Opera House, Charni Road, Mumbai has a rating of 4.4\n", "The average price of Rs.1800 for two persons\n", "The Nutcracker in C/2, Diamond Arch Cooperative Housing Society, St. John Baptist Road, Bandstand, Bandra West, Mumbai has a rating of 4.4\n", "The average price of Rs.1200 for two persons\n"]}
    - action_send_email
    - slot{"email": "raj29shenoy@gmail.com"}
* goodbye OR gratitude
    - action_restart

## location first
* greet
    - utter_greet
* restaurant_search{"location": "Shimla"}
    - slot{"location": "Shimla"}
    - action_check_city
    - slot{"location": 19}
    - utter_ask_cuisine
* cuisine{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - action_check_cuisine
    - slot{"cuisine": "american"}
    - utter_ask_price_range
* price{"price": "3"}
    - slot{"price": "3"}
    - action_check_price
    - slot{"price": "3"}
    - action_search_restaurants
    - slot{"emailmsg": ["Seventeen Degrees Restaurant in Sriram Mall, Ashok Nagar, Dhanbad - 826001, Dhanbad Locality, Dhanbad has a rating of 4.4\n", "The average price of Rs.400 for two persons\n", "Aranya's in Chanakya Nagar, Dhanbad - 828127, Dhanbad Locality, Dhanbad has a rating of 4.1\n", "The average price of Rs.400 for two persons\n", "Aroti Restaurant in Hira Palace, Hatia Road, Hirapur, Dhanbad - 826001, Near Fashion World, Dhanbad Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.450 for two persons\n", "National Darbar Fast Food in Bhuli Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.300 for two persons\n", "Status Restaurant in Savitree Apartment, Shastri Nagar, Dhanbad - 826001, Bank More, Dhanbad Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.700 for two persons\n", "Green Leaf in Ground Floor, Jai Ganesh Complex, Jora Phatak Road, Purrana Bazar, Dhanbad - 826001, Opposite Shakti Mandir Road, Dhanbad Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.350 for two persons\n", "Tiwari Hotel in He School Road, Dhanbad Hirapur, Dhanbad - 826001, Near Vinod Market, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.300 for two persons\n", "Champaran Meat House in Krishna tower, Near Big bazar, Saraidhela, Dhanbad, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.400 for two persons\n", "Thyme by wedlock greens in kashitand, govindpur, NH-2 Bithia more, gobindpur dhanbad-, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.500 for two persons\n", "Bits & Bites in Sita Niwas, Teliphone Exchange Road, Ps Bankmore, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.500 for two persons\n"]} 
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## location and cuisine first
* greet
    - utter_greet
* restaurant_search{"cuisine": "north indian", "location": "Dhanbad"}
    - slot{"cuisine": "north indian"}
    - slot{"location": "Dhanbad"}
    - action_check_city
    - slot{"location": 11387}
    - action_check_cuisine
    - slot{"cuisine": "north indian"}
    - utter_ask_price_range
* price{"price": "2"}
    - slot{"price": "2"}
    - action_check_price
    - slot{"price": "2"}
    - action_search_restaurants
    - slot{"emailmsg": ["Seventeen Degrees Restaurant in Sriram Mall, Ashok Nagar, Dhanbad - 826001, Dhanbad Locality, Dhanbad has a rating of 4.4\n", "The average price of Rs.400 for two persons\n", "Aranya's in Chanakya Nagar, Dhanbad - 828127, Dhanbad Locality, Dhanbad has a rating of 4.1\n", "The average price of Rs.400 for two persons\n", "Aroti Restaurant in Hira Palace, Hatia Road, Hirapur, Dhanbad - 826001, Near Fashion World, Dhanbad Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.450 for two persons\n", "National Darbar Fast Food in Bhuli Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.300 for two persons\n", "Status Restaurant in Savitree Apartment, Shastri Nagar, Dhanbad - 826001, Bank More, Dhanbad Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.700 for two persons\n", "Green Leaf in Ground Floor, Jai Ganesh Complex, Jora Phatak Road, Purrana Bazar, Dhanbad - 826001, Opposite Shakti Mandir Road, Dhanbad Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.350 for two persons\n", "Tiwari Hotel in He School Road, Dhanbad Hirapur, Dhanbad - 826001, Near Vinod Market, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.300 for two persons\n", "Champaran Meat House in Krishna tower, Near Big bazar, Saraidhela, Dhanbad, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.400 for two persons\n", "Thyme by wedlock greens in kashitand, govindpur, NH-2 Bithia more, gobindpur dhanbad-, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.500 for two persons\n", "Bits & Bites in Sita Niwas, Teliphone Exchange Road, Ps Bankmore, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.500 for two persons\n"]}
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## location and price first
* greet
    - utter_greet
* restaurant_search{"price": "400 rupee", "location": "Malappuram"}
    - slot{"location": "Malappuram"}
    - slot{"price": "400 rupee"}
    - action_check_city
    - slot{"location": 11775}
    - utter_ask_cuisine
* cuisine{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_check_cuisine
    - slot{"cuisine": "south indian"}
    - action_check_price
    - slot{"price": "2"}
    - action_search_restaurants
    - slot{"emailmsg": ["Seventeen Degrees Restaurant in Sriram Mall, Ashok Nagar, Dhanbad - 826001, Dhanbad Locality, Dhanbad has a rating of 4.4\n", "The average price of Rs.400 for two persons\n", "Aranya's in Chanakya Nagar, Dhanbad - 828127, Dhanbad Locality, Dhanbad has a rating of 4.1\n", "The average price of Rs.400 for two persons\n", "Aroti Restaurant in Hira Palace, Hatia Road, Hirapur, Dhanbad - 826001, Near Fashion World, Dhanbad Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.450 for two persons\n", "National Darbar Fast Food in Bhuli Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.300 for two persons\n", "Status Restaurant in Savitree Apartment, Shastri Nagar, Dhanbad - 826001, Bank More, Dhanbad Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.700 for two persons\n", "Green Leaf in Ground Floor, Jai Ganesh Complex, Jora Phatak Road, Purrana Bazar, Dhanbad - 826001, Opposite Shakti Mandir Road, Dhanbad Locality, Dhanbad has a rating of 4.0\n", "The average price of Rs.350 for two persons\n", "Tiwari Hotel in He School Road, Dhanbad Hirapur, Dhanbad - 826001, Near Vinod Market, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.300 for two persons\n", "Champaran Meat House in Krishna tower, Near Big bazar, Saraidhela, Dhanbad, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.400 for two persons\n", "Thyme by wedlock greens in kashitand, govindpur, NH-2 Bithia more, gobindpur dhanbad-, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.500 for two persons\n", "Bits & Bites in Sita Niwas, Teliphone Exchange Road, Ps Bankmore, Dhanbad Locality, Dhanbad has a rating of 3.9\n", "The average price of Rs.500 for two persons\n"]}    
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## cuisine first
* greet
    - utter_greet
* restaurant_search{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - action_check_cuisine
    - slot{"cuisine": "north indian"}
    - utter_ask_location
* location{"location": "erode"}
    - slot{"location": "erode"}
    - action_check_city
    - slot{"location": "11350"}
    - utter_ask_price_range
* price{"price": "Rs.100 to 200 rupee"}
    - slot{"price": "Rs.100 to 200 rupee"}
    - action_check_price
    - slot{"price": "1"}
    - action_search_restaurants
    - slot{"emailmsg": ["Eeebees Bakery in 58/1 Gandhiji Road, Near Corporation Bank, Erode, Periyar Nagar, Erode has a rating of 4.4.", "The average price of Rs.150 for two persons\n", "New Fast Food in NO-94/54, Athiyaman Nagar, 16 Main Road, Periyasemur, Asokapuram, Erode-638004 has a rating of 4.4.", "The average price of Rs.150 for two persons\n", "Eeebees Bakery in 372, E.V.N Road, Erode, Periyar Nagar, Erode has a rating of 4.4.", "The average price of Rs.200 for two persons\n", "Hotel Sri Balaji Bhavan in 5, kanjikoil road, near Anna statue, Perundurai, Erode, Perundurai Locality, Erode has a rating of 4.4.", "The average price of Rs.150 for two persons\n", "Hotel Amudha Bawan in 102-1/150, Sampath Nagar, Main road Erode, Edayankattuvalasu, Erode has a rating of 4.3.", "The average price of Rs.200 for two persons\n", "Chimney Restaurant in 21, Old Railway Station Road, Railway Colony, Near Railway Station, Periyar Nagar, Erode has a rating of 4.2.", "The average price of Rs.250 for two persons\n", "Sri Nila Fast Food in 221, Brough road, Erode, Erode Fort, Erode has a rating of 4.2.", "The average price of Rs.200 for two persons\n", "Paviesh Park in 5/1173-A, Salem by-pass road, Lakshmi nagar, Erode, Bhavani Locality, Erode has a rating of 4.2.", "The average price of Rs.250 for two persons\n", "Erode food mall in 35, Thiru vi ka Road, Municipal colony, Erode-638004, Edayankattuvalasu, Erode has a rating of 4.1.", "The average price of Rs.200 for two persons\n", "Kokkarakko Biriyani and Fast food in 153, parvathi street, kollampalayam, Erode, Kollampalayam, Erode has a rating of 4.1.", "The average price of Rs.200 for two persons\n"]}
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## cuisine and price first
* greet
    - utter_greet
* restaurant_search{"cuisine": "north indian", "price": "600 rs"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "600 rs"}
    - action_check_cuisine
    - slot{"cuisine": "north indian"}
    - action_check_price
    - slot{"price": "2"}
    - utter_ask_location
* location{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - action_check_city
    - slot{"location": "3"}
    - action_search_restaurants
    - slot{"emailmsg": ["A.Rama Nayak's Udipi Shri Krishna Boarding in 1st Floor, LBS Market Building, Near Matunga Central Railway Station, Matunga East, Mumbai has a rating of 4.8\n", "The average price of Rs.400 for two persons\n", "Merwans Cake Stop in 9/12, Madhav Nagar, SV Road, Near Andheri West Station, Mumbai has a rating of 4.8\n", "The average price of Rs.300 for two persons\n", "Monginis in 3, Building 9, Highland Park, Highland Dhokali Road, Majiwada, Thane West, Thane has a rating of 4.8\n", "The average price of Rs.300 for two persons\n", "Saucepan in Mira Road, Mumbai has a rating of 4.8\n", "The average price of Rs.500 for two persons\n", "Hearsch Bakery in 90/A, Next to Holy Family Hospital, Hill Road, Bandra West, Mumbai has a rating of 4.7\n", "The average price of Rs.400 for two persons\n", "Vinay Health Home in Jawar Mansion, Dr BA Jaikar Marg, Charni Road, Mumbai has a rating of 4.7\n", "The average price of Rs.400 for two persons\n", "Live2Eat Desserts in Santacruz West, Mumbai has a rating of 4.7\n", "The average price of Rs.400 for two persons\n", "McCafe by McDonald's in Shop 1, Urban Plaza, Plot C5, GN Block, Bandra Kurla Complex, Mumbai has a rating of 4.7\n", "The average price of Rs.500 for two persons\n", "Ribbons And Balloons in Shop 3, Plot 35, Avinash Building, Sector 20, Near Bharat Gas, Kharghar, Navi Mumbai has a rating of 4.7\n", "The average price of Rs.300 for two persons\n", "Fruitiffin in Row House J1, Ground Floor, Sector 4, Airoli, Navi Mumbai has a rating of 4.7\n", "The average price of Rs.300 for two persons\n"]}
    - utter_ask_email
* affirm OR gratitude
    - utter_request_emailid
* send_email{"email": "g_shenoy@yahoomail.com"}
    - slot{"email": "g_shenoy@yahoomail.com"}
    - action_send_email
    - slot{"email": "g_shenoy@yahoomail.com"}
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## price first
* greet
    - utter_greet
* restaurant_search{"price": "650"}
    - slot{"price": "650"}
    - action_check_price
    - slot{"price": "2"}
    - utter_ask_location
* location{"location": "Ujjain"}
    - slot{"location": "Ujjain"}
    - action_check_city
    - slot{"location": "11316"}
    - utter_ask_cuisine
* cuisine{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_check_cuisine
    - slot{"cuisine": "north indian"}
    - action_search_restaurants
    - slot{"emailmsg": ["N X Malhotra Restaurant in 20 saidham colony near machaman colony, Pawapuri Colony, Ujjain has a rating of 4.5\n", "The average price of Rs.300 for two persons\n", "Lahori Restaurant in Ground Floor, Divine Valley near ICICI Bank. Dewas road Rishi nagar. has a rating of 4.2\n", "The average price of Rs.350 for two persons\n", "Real Mini Chaupati in 52/2, Varuchi Marg, Freeganj Ujjain, Pawapuri Colony, Ujjain has a rating of 4.2\n", "The average price of Rs.350 for two persons\n", "Shree Ganga in 50, Ramakrishan Colony, opp Ujjain public school, Dewas Road,  Ujjain has a rating of 4.1\n", "The average price of Rs.300 for two persons\n", "Hotel Sai Palace in 23, Bhaktawar Marg, Freeganj, Pawapuri Colony, Ujjain has a rating of 4.1\n", "The average price of Rs.500 for two persons\n", "New Rajkumar Restaurant in 20, Bhaktawar Marg, Near Madhav Nagar Police Station, Pawapuri Colony, Freeganj Ujjain has a rating of 4.1\n", "The average price of Rs.350 for two persons\n", "Apna Sweets in 61/2,Vishwavidyalaya Marg,Azaad Nagar Chouraha,Ujjain has a rating of 4.1\n", "The average price of Rs.400 for two persons\n", "Rajkumar Restaurant in 34/4, 2nd Floor, Above Bata Showoom, Tower Chowk, Freeganj, Ujjain has a rating of 4.1\n", "The average price of Rs.400 for two persons\n", "Time Headquarters in 301 third floor mahakal samapanna m no 28 varaha mihir Marg tawar chok ujjain, Pawapuri Colony, Ujjain has a rating of 4.1\n", "The average price of Rs.400 for two persons\n", "Chanakya Restaurant in 30 subash marg  station road Pawapuri Colony, Ujjain has a rating of 4.1\n", "The average price of Rs.300 for two persons\n"]}
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"price": "Rs405", "location": "delhi"}
    - slot{"location": "delhi"}
    - slot{"price": "Rs405"}
    - action_check_city
    - slot{"location": 1}
    - utter_ask_cuisine
* cuisine{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_check_cuisine
    - slot{"cuisine": "north indian"}
    - action_check_price
    - slot{"price": "2"}
    - action_search_restaurants
    - slot{"emailmsg": ["Noida Big Bang Cafe in Sector 72, Noida has a rating of 4.9\n", "The average price of Rs.500 for two persons\n", "Urban Kitchen in 131, 1st Floor, Manglam Paradise Mall, Sector 3, Rohini, New Delhi has a rating of 4.8\n", "The average price of Rs.500 for two persons\n", "Juggernaut in HS-16, Main Market, Kailash Colony, New Delhi has a rating of 4.7\n", "The average price of Rs.700 for two persons\n", "Desi Pakwaan in Block- 13, H. No- 244, 4th floor, Geeta Colony Delhi, Near 14 Block Gurudwara has a rating of 4.7\n", "The average price of Rs.300 for two persons\n", "Chicken Changezi Corner in 37, Corner Market, Near Karim Restaurant, Malviya Nagar, New Delhi has a rating of 4.7\n", "The average price of Rs.500 for two persons\n", "Kake Di Hatti in 654 666, Fatehpuri, Church Mission Road, Chandni Chowk, New Delhi has a rating of 4.6\n", "The average price of Rs.500 for two persons\n", "Ghee And Turmeric in Sector 14, Gurgaon has a rating of 4.6\n", "The average price of Rs.500 for two persons\n", "Gullu's in ITL Twin Tower, Netaji Subhash Place, New Delhi has a rating of 4.6\n", "The average price of Rs.500 for two persons\n", "Nukkad on Wheels in C 23-24, SDA Market, SDA, New Delhi has a rating of 4.6\n", "The average price of Rs.600 for two persons\n", "The Maggis Kitchen in Flat 4474, Gate 3, Pocket 5-6, Sector B, Vasant Kunj, New Delhi has a rating of 4.6\n", "The average price of Rs.400 for two persons\n"]}
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

## interactive_story_2
* restaurant_search{"price": "<Rs600"}
    - slot{"price": "<Rs600"}
    - action_check_price
    - slot{"price": "2"}
    - utter_ask_location
* location{"location": "Patna"}
    - slot{"location": "Patna"}
    - action_check_city
    - slot{"location": 40}
    - utter_ask_cuisine
* cuisine{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_check_cuisine
    - slot{"cuisine": "north indian"}
    - action_search_restaurants
    - slot{"emailmsg": ["Harilal's in West Boring Canal Road, Kidwaipuri, Patna has a rating of 4.5\n", "The average price of Rs.300 for two persons\n", "Haldiram in Rajeswar Commercial Complex, Main Road, Kankarbagh, Patna has a rating of 4.4\n", "The average price of Rs.500 for two persons\n", "Basant Vihar in 1st Floor, Maurya Lok Complex, Fraser Road Area, Patna has a rating of 4.4\n", "The average price of Rs.600 for two persons\n", "17 Degrees in 6th Floor, P&M Mall, Kurji has a rating of 4.4\n", "The average price of Rs.700 for two persons\n", "Bikaner Sweets in 23B, Azad Bhawan, Boring Road, Sri Krishnapuri, Patna has a rating of 4.4\n", "The average price of Rs.350 for two persons\n", "0612 Road Chef in Commercial Space 1, Krishna Apartment, Boring Road, Sri Krishnapuri, Patna has a rating of 4.4\n", "The average price of Rs.300 for two persons\n", "Haldiram in Uno Business Center, Polytechnic More, Patliputra, Patliputra Colony, Patna has a rating of 4.3\n", "The average price of Rs.500 for two persons\n", "Swaaddesh in 2nd Floor, Chandra Complex, Above Manyavar, Boring Road, Sri Krishnapuri, Patna has a rating of 4.3\n", "The average price of Rs.700 for two persons\n", "Bikaner Sweets & Elite Restaurant in Jagdeo Path, Bailey Raod, Khajpura, Patna has a rating of 4.3\n", "The average price of Rs.350 for two persons\n", "Dancing Noodles in Besides V-Mart, Main Road, Rajeev Nagar, Patna has a rating of 4.3\n", "The average price of Rs.500 for two persons\n"]}
    - utter_ask_email
* deny
    - utter_no_email
* goodbye OR gratitude
    - utter_goodbye
    - action_restart

